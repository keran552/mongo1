WITH BASE
     AS (  SELECT C_PRTY_RLTD_ORG_XREF.ROWID_OBJECT,
                  C_PRTY_RLTD_ORG_XREF.ORG_UNIT_ID,
                  C_PRTY_RLTD_ORG.ORG_UNIT_ID AS ORG_UNIT_ID_SRC,
                  C_PRTY_RLTD_ORG.LAST_UPDATE_DATE,
                  C_PRTY_XREF.BUS_ACTV_TYP_CD,
                  CASE
                     WHEN TRIM (C_PRTY_RLTD_ORG_XREF.ROWID_SYSTEM) IN
                             ('CD', 'EQ', 'WA', 'CA', 'TP', 'DA')
                     THEN
                        'CD'
                     ELSE
                        TRIM (C_PRTY_RLTD_ORG_XREF.ROWID_SYSTEM)
                  END
                     AS ROWID_SYSTEM,
                  C_PRTY_XREF.CUST_LCYCL_STAT_CD,
                  C_PRTY_XREF.RLTD_PRTY_LCYCL_STAT_CD,
                  REGEXP_SUBSTR (C_PRTY_XREF.CUST_LCYCL_STAT_CD, '[^~]+$')
                     AS CUST_LCYCL_STATUS,
                  REGEXP_SUBSTR (C_PRTY_XREF.RLTD_PRTY_LCYCL_STAT_CD, '[^~]+$')
                     AS RLTD_LCYCL_STATUS,
                  C_PRTY_RLTD_ORG_XREF.PRTY_RLTD_ORG_END_DT
             FROM BOW_ORS.C_PRTY_RLTD_ORG_XREF,
                  BOW_ORS.C_PRTY_RLTD_ORG,
                  BOW_ORS.C_PRTY_XREF,
                  BOW_ORS.C_PRTY
            WHERE     C_PRTY_RLTD_ORG_XREF.ROWID_OBJECT =
                         C_PRTY_RLTD_ORG.ROWID_OBJECT
                  AND C_PRTY_XREF.ROWID_XREF = C_PRTY_RLTD_ORG_XREF.PRTY_ID
                  AND C_PRTY.ROWID_OBJECT = C_PRTY_RLTD_ORG.PRTY_ID
                  AND C_PRTY.CONSOLIDATION_IND IN (1, 2) /*AND C_PRTY_RLTD_ORG.PRTY_ID = '20000095'*/
--                  AND (   C_PRTY_RLTD_ORG.LAST_UPDATE_DATE >=
--                             TO_DATE ('07/24/2018 13:21:54',
--                                      'MM:DD:YYYY HH24:MI:SS')
--                       OR C_PRTY_RLTD_ORG_XREF.LAST_UPDATE_DATE >=
--                             TO_DATE ('07/24/2018 13:21:54',
--                                      'MM:DD:YYYY HH24:MI:SS')
--                       OR C_PRTY_XREF.LAST_UPDATE_DATE >=
--                             TO_DATE ('07/24/2018 13:21:54',
--                                      'MM:DD:YYYY HH24:MI:SS'))
                  AND C_PRTY_RLTD_ORG_XREF.ROWID_SYSTEM NOT IN ('PM', 'MD')
                  AND C_PRTY_RLTD_ORG_XREF.PRTY_RLTD_ORG_TYP_CD =
                         'PRTYORGTYP~LOB'
                  AND NOT (    TRIM (C_PRTY_RLTD_ORG_XREF.ROWID_SYSTEM) IN
                                  ('CD', 'EQ', 'WA', 'CA', 'TP')
                           AND C_PRTY_XREF.CUST_LCYCL_STAT_CD =
                                  'PTYLIFCYCSTAT~CLOSED')
                  AND C_PRTY_RLTD_ORG_XREF.HUB_STATE_IND = 1
                  AND C_PRTY_RLTD_ORG.HUB_STATE_IND = 1
                  AND C_PRTY_XREF.HUB_STATE_IND = 1
                  AND C_PRTY.HUB_STATE_IND = 1
         ORDER BY C_PRTY_RLTD_ORG_XREF.ROWID_OBJECT),
     FLG
     AS (SELECT /*+PARALLEL(5)*/ CDD_CNT,
                END_DT,
                CASE
                   WHEN    (    ROWID_SYSTEM != 'CD'
                            AND END_DT = 1
                            AND PRTY_RLTD_ORG_END_DT =
                                   TO_DATE (99991231, 'YYYYMMDD'))
                        OR (ROWID_SYSTEM != 'CD' AND END_DT = 0)
                        OR (ROWID_SYSTEM = 'CD')
                   THEN
                      1
                   ELSE
                      0
                END
                   AS PRIOR_FLG,
                B.*
           FROM BASE B,
                (  SELECT 
                         ROWID_OBJECT,
                          SUM (
                             CASE WHEN ROWID_SYSTEM LIKE 'CD' THEN 1 ELSE 0 END)
                             CDD_CNT,
                          COUNT (ROWID_SYSTEM) AS SYS_CNT,
                          SUM (
                             CASE WHEN ROWID_SYSTEM LIKE 'CM' THEN 1 ELSE 0 END)
                             CM_CNT,
                          MAX (
                             CASE
                                WHEN PRTY_RLTD_ORG_END_DT =
                                        TO_DATE (99991231, 'YYYYMMDD')
                                THEN
                                   1
                                ELSE
                                   0
                             END)
                             END_DT
                     FROM BASE
                 GROUP BY ROWID_OBJECT) F
          WHERE     B.ROWID_OBJECT = F.ROWID_OBJECT
                AND NOT (SYS_CNT = 1 AND CM_CNT = 1)),
     HIER
     AS (SELECT H.*,
                DENSE_RANK () OVER (PARTITION BY ROWID_OBJECT ORDER BY HIER)
                   AS HIER_RANK
           FROM (SELECT ROWID_OBJECT,
                        ORG_UNIT_ID,
                        ORG_UNIT_ID_SRC,
                        LAST_UPDATE_DATE,
                        BUS_ACTV_TYP_CD,
                        ROWID_SYSTEM,
                        CDD_CNT,
                        CUST_LCYCL_STATUS,
                        RLTD_LCYCL_STATUS,
                        (CASE
                            WHEN     CDD_CNT = 1
                                 AND NOT (   CUST_LCYCL_STATUS = 'NA'
                                          OR CUST_LCYCL_STATUS IS NULL)
                                 AND ROWID_SYSTEM = 'CD'
                            THEN
                               1
                            WHEN     CDD_CNT > 1
                                 AND NOT (   CUST_LCYCL_STATUS = 'NA'
                                          OR CUST_LCYCL_STATUS IS NULL)
                                 AND ROWID_SYSTEM = 'CD'
                            THEN
                               2
                            WHEN     ROWID_SYSTEM NOT IN
                                        ('CM', 'PM', 'MD', 'HV', 'UI')
                                 AND CUST_LCYCL_STATUS = 'OPEN'
                            THEN
                               3
                            WHEN     ROWID_SYSTEM NOT IN
                                        ('CM', 'PM', 'MD', 'HV', 'UI')
                                 AND CUST_LCYCL_STATUS = 'CLOSED'
                            THEN
                               4
                            WHEN     CDD_CNT = 1
                                 AND (   CUST_LCYCL_STATUS = 'NA'
                                      OR CUST_LCYCL_STATUS IS NULL)
                                 AND ROWID_SYSTEM = 'CD'
                                 AND RLTD_LCYCL_STATUS = 'OPEN'
                            THEN
                               5
                            WHEN     CDD_CNT > 1
                                 AND (   CUST_LCYCL_STATUS = 'NA'
                                      OR CUST_LCYCL_STATUS IS NULL)
                                 AND ROWID_SYSTEM = 'CD'
                                 AND RLTD_LCYCL_STATUS = 'OPEN'
                            THEN
                               6
                            WHEN     CDD_CNT > 1
                                 AND (   CUST_LCYCL_STATUS = 'NA'
                                      OR CUST_LCYCL_STATUS IS NULL)
                                 AND ROWID_SYSTEM = 'CD'
                                 AND RLTD_LCYCL_STATUS = 'CLOSED'
                            THEN
                               7
                            WHEN     ROWID_SYSTEM NOT IN
                                        ('CM', 'PM', 'MD', 'HV', 'UI')
                                 AND (   CUST_LCYCL_STATUS = 'NA'
                                      OR CUST_LCYCL_STATUS IS NULL)
                                 AND RLTD_LCYCL_STATUS = 'OPEN'
                            THEN
                               8
                            WHEN     ROWID_SYSTEM NOT IN
                                        ('CM', 'PM', 'MD', 'HV', 'UI')
                                 AND (   CUST_LCYCL_STATUS = 'NA'
                                      OR CUST_LCYCL_STATUS IS NULL)
                                 AND RLTD_LCYCL_STATUS = 'CLOSED'
                            THEN
                               9
                            WHEN     ROWID_SYSTEM NOT IN
                                        ('CM', 'PM', 'MD', 'HV', 'UI')
                                 AND (   CUST_LCYCL_STATUS = 'NA'
                                      OR CUST_LCYCL_STATUS IS NULL)
                                 AND (   RLTD_LCYCL_STATUS = 'NA'
                                      OR RLTD_LCYCL_STATUS IS NULL)
                            THEN
                               10
                         END)
                           AS HIER
                   FROM FLG WHERE PRIOR_FLG = 1) H)
SELECT ROWID_OBJECT,
       CASE WHEN HIER IN (4, 7, 9) THEN ORG_UNIT_ID_SRC ELSE ORG_UNIT_ID END
          AS ORG_UNIT_ID,
       LAST_UPDATE_DATE,
       BUS_ACTV_TYP_CD,
       ROWID_SYSTEM,
       HIER
  FROM HIER
 WHERE HIER_RANK = 1 
 ORDER BY ROWID_OBJECT