CREATE OR REPLACE PROCEDURE BULK_UPDATE (TCPA_PRTY_INFO       CLOB,
                                         TCPA_ACCT_INFO       CLOB,
                                         STATUS           OUT VARCHAR2,
                                         STATUSMESSAGE    OUT VARCHAR2)
IS
   /*=====================================================================
   * Constants declaration begins
   *=====================================================================*/
   V_TCPA_PRTY_INFO   XMLTYPE;
   V_TCPA_ACCT_INFO   XMLTYPE;
   V_PARTYID          VARCHAR2 (100);
   V_UNAME            VARCHAR2 (100);
   V_PHSTATUS         VARCHAR2 (100);
   V_PHID             VARCHAR2 (100);
   V_PHSTATUS         VARCHAR2 (100);
   V_ACCTID           VARCHAR2 (100);
   V_A_PHID           VARCHAR2 (100);
   V_A_CDFLAG         VARCHAR2 (100);
   V_A_CDEDATE        VARCHAR2 (100);
   V_A_CDBID          VARCHAR2 (100);
   V_A_PHSTATUS       VARCHAR2 (100);
   V_A_SCFLAG         VARCHAR2 (100);
   V_A_TCFLAG         VARCHAR2 (100);
   V_A_CEDATE         VARCHAR2 (100);
   V_A_CCHANNEL       VARCHAR2 (100);
   V_A_TBID           VARCHAR2 (100);
   V_A_CSID           VARCHAR2 (100);
   V_COUNT            VARCHAR2 (100);
   i                  BINARY_INTEGER := 1;
   j                  BINARY_INTEGER := 1;
   acct               BINARY_INTEGER := 1;
/*=====================================================================
* Constants declaration ends
*=====================================================================*/
BEGIN
   IF TCPA_PRTY_INFO <> EMPTY_CLOB () AND TCPA_ACCT_INFO <> EMPTY_CLOB ()
   THEN
      V_TCPA_PRTY_INFO := XMLType (TCPA_PRTY_INFO);
      V_TCPA_ACCT_INFO := XMLType (TCPA_ACCT_INFO);

      /*TCPA PARTY Info*/
      IF V_TCPA_PRTY_INFO.EXISTSNODE ('/party/id[' || TO_CHAR (i) || ']') = 1
      THEN
         SELECT EXTRACTVALUE (VALUE (xml_list), '//id/text()')
           INTO V_PARTYID
           FROM TABLE (XMLSEQUENCE (EXTRACT (V_TCPA_PRTY_INFO, '/party/id')))
                xml_list;

         SELECT EXTRACTVALUE (VALUE (xml_list), '//userName/text()')
           INTO V_UNAME
           FROM TABLE (XMLSEQUENCE (EXTRACT (V_TCPA_PRTY_INFO, '/party')))
                xml_list;

         FOR C
            IN (SELECT EXTRACTVALUE (VALUE (xml_list), '//phid/text()')
                          AS V_PHID,
                       EXTRACTVALUE (VALUE (xml_list),
                                     '//phoneStatus/text()')
                          AS V_PHSTATUS
                  FROM TABLE (
                          XMLSEQUENCE (
                             EXTRACT (
                                V_TCPA_PRTY_INFO,
                                '/party/electronicAddresses/phoneNumber')))
                       xml_list)
         LOOP
            MERGE INTO ESB_PRTY P
                 USING (SELECT V_PARTYID    AS PARTYID,
                               V_UNAME      AS UNAME,
                               C.V_PHID     AS PHID,
                               C.V_PHSTATUS AS PHSTATUS
                          FROM DUAL) SP
                    ON (    TRIM (P.PARTYID) = TRIM (SP.PARTYID)
                        AND TRIM (P.ELECTRONICADDRESSKEYID) = TRIM (PHID)
                        AND TRIM (P.MSG_STAT_CD) = 'NEW')
            WHEN MATCHED
            THEN
               UPDATE SET
                  P.ELECTRONICADDRESSPHONESTATUS =
                     NVL (SP.PHSTATUS, P.ELECTRONICADDRESSPHONESTATUS),
                  UPDATE_DTTM = SYSDATE,
                  UPDATED_BY = SP.UNAME
            WHEN NOT MATCHED
            THEN
               INSERT     (PARTYID,
                           ELECTRONICADDRESSKEYID,
                           ELECTRONICADDRESSPHONESTATUS,
                           MSG_STAT_CD,
                           INSERT_DTTM,
                           CREATED_BY)
                   VALUES (SP.PARTYID,
                           SP.PHID,
                           SP.PHSTATUS,
                           'NEW',
                           SYSDATE,
                           SP.UNAME);

            --COMMIT;

            --            DBMS_OUTPUT.PUT_line (V_PARTYID);
            --            DBMS_OUTPUT.PUT_line (C.V_PHID);
            --            DBMS_OUTPUT.PUT_line (C.V_PHSTATUS);
            /*TCPA ACCT Info*/
            IF     V_TCPA_PRTY_INFO.EXISTSNODE (
                      '/party/id[' || TO_CHAR (j) || ']') = 1
               AND V_TCPA_ACCT_INFO.EXISTSNODE (
                      '/accounts/account/id[' || TO_CHAR (j) || ']') = 1
            THEN
               FOR C
                  IN (SELECT EXTRACTVALUE (VALUE (xml_list), '//id/text()')
                                AS V_ACCTID,
                             EXTRACTVALUE (VALUE (xml_list),
                                           '//ceaseDesistFlag/text()')
                                AS V_A_CDFLAG,
                             EXTRACTVALUE (VALUE (xml_list),
                                           '//ceaseDesistEffDt/text()')
                                AS V_A_CDEDATE,
                             EXTRACTVALUE (VALUE (xml_list),
                                           '//ceaseDesistBankerLanId/text()')
                                AS V_A_CDBID
                        FROM TABLE (
                                XMLSEQUENCE (
                                   EXTRACT (V_TCPA_ACCT_INFO,
                                            '/accounts/account'))) xml_list)
               LOOP
                  MERGE INTO ESB_ACCT P
                       USING (SELECT V_PARTYID    AS PARTYID,
                                     V_UNAME      AS UNAME,
                                     C.V_ACCTID   AS ACCTID,
                                     C.V_A_CDFLAG AS CDFLAG,
                                     TO_DATE (C.V_A_CDEDATE, 'YYYY-MM-DD')
                                        AS CDEDATE,
                                     C.V_A_CDBID  AS CDBID
                                FROM DUAL) SP
                          ON (    TRIM (P.PARTYID) = TRIM (SP.PARTYID)
                              AND TRIM (P.ACCOUNTID) = TRIM (SP.ACCTID)
                              AND TRIM (P.MSG_STAT_CD) = 'NEW')
                  WHEN MATCHED
                  THEN
                     UPDATE SET P.CEASEDESISTFLAG = SP.CDFLAG,
                                P.CEASEDESISTEFFDT = SP.CDEDATE,
                                P.BANKERLANID = SP.CDBID,
                                UPDATE_DTTM = SYSDATE,
                                UPDATED_BY = SP.UNAME
                  WHEN NOT MATCHED
                  THEN
                     INSERT     (PARTYID,
                                 ACCOUNTID,
                                 CEASEDESISTFLAG,
                                 CEASEDESISTEFFDT,
                                 BANKERLANID,
                                 MSG_STAT_CD,
                                 INSERT_DTTM,
                                 CREATED_BY)
                         VALUES (SP.PARTYID,
                                 SP.ACCTID,
                                 SP.CDFLAG,
                                 SP.CDEDATE,
                                 SP.CDBID,
                                 'NEW',
                                 SYSDATE,
                                 SP.UNAME);

                  --COMMIT;

                  /*TCPA ACCT ELECTRONICADDRESS Info*/

                  FOR S
                     IN (SELECT EXTRACTVALUE (VALUE (xml_list),
                                              '//phid/text()')
                                   AS V_A_PHID,
                                EXTRACTVALUE (VALUE (xml_list),
                                              '//phoneStatus/text()')
                                   AS V_A_PHSTATUS,
                                EXTRACTVALUE (VALUE (xml_list),
                                              '//smsConsentFlag/text()')
                                   AS V_A_SCFLAG,
                                EXTRACTVALUE (VALUE (xml_list),
                                              '//tcpaConsentFlag/text()')
                                   AS V_A_TCFLAG,
                                EXTRACTVALUE (VALUE (xml_list),
                                              '//consentEffDt/text()')
                                   AS V_A_CEDATE,
                                EXTRACTVALUE (VALUE (xml_list),
                                              '//consentChannel/text()')
                                   AS V_A_CCHANNEL,
                                EXTRACTVALUE (VALUE (xml_list),
                                              '//tcpaBankerLanId/text()')
                                   AS V_A_TBID,
                                EXTRACTVALUE (VALUE (xml_list),
                                              '//consentScriptId/text()')
                                   AS V_A_CSID
                           FROM TABLE (
                                   XMLSEQUENCE (
                                      EXTRACT (
                                         V_TCPA_ACCT_INFO,
                                            '/accounts/account['
                                         || TO_CHAR (acct)
                                         || ']/electronicAddresses/phoneNumber')))
                                xml_list)
                  LOOP
                     MERGE INTO ESB_ACCT_ELECADDR_CONSENTINFO P
                          USING (SELECT C.V_ACCTID     AS ACCTID,
                                        V_UNAME        AS UNAME,
                                        S.V_A_PHSTATUS AS PHSTATUS,
                                        S.V_A_PHID     AS PHID,
                                        S.V_A_SCFLAG   AS SCFLAG,
                                        S.V_A_TCFLAG   AS TCFLAG,
                                        TO_DATE (S.V_A_CEDATE, 'YYYY-MM-DD')
                                           AS CEDATE,
                                        S.V_A_CCHANNEL AS CCHANNEL,
                                        S.V_A_TBID     AS TBID,
                                        S.V_A_CSID     AS CSID
                                   FROM DUAL) SP
                             ON (    TRIM (P.ACCOUNTID) = TRIM (SP.ACCTID)
                                 AND TRIM (P.ELECTRONICADDRESSKEYID) =
                                        TRIM (PHID)
                                 AND TRIM (P.MSG_STAT_CD) = 'NEW')
                     WHEN MATCHED
                     THEN
                        UPDATE SET
                           P.ELECTRONICADDRESSPHONESTATUS =
                              NVL (SP.PHSTATUS,
                                   P.ELECTRONICADDRESSPHONESTATUS),
                           P.ELECTRONICADDRESSTCPACONSENFLG =
                              NVL (SP.TCFLAG,
                                   P.ELECTRONICADDRESSTCPACONSENFLG),
                           P.ELECTRONICADDRESSSMSCONSENFLAG =
                              NVL (SP.SCFLAG,
                                   P.ELECTRONICADDRESSSMSCONSENFLAG),
                           P.ELECTRONICADDRESSCONSENTCHANEL =
                              NVL (SP.CCHANNEL,
                                   P.ELECTRONICADDRESSCONSENTCHANEL),
                           P.ELECTRONICADDRESSCONSENTEFFDT =
                              NVL (SP.CEDATE,
                                   P.ELECTRONICADDRESSCONSENTEFFDT),
                           P.ELECTRONICADDRESSCONSENTSCTID =
                              NVL (SP.CSID, P.ELECTRONICADDRESSCONSENTSCTID),
                           P.ELECTRONICADDRESSTCPABANKENID =
                              NVL (SP.TBID, ELECTRONICADDRESSTCPABANKENID),
                           UPDATE_DTTM = SYSDATE,
                           UPDATED_BY = SP.UNAME
                     WHEN NOT MATCHED
                     THEN
                        INSERT     (ACCOUNTID,
                                    ELECTRONICADDRESSKEYID,
                                    ELECTRONICADDRESSPHONESTATUS,
                                    ELECTRONICADDRESSTCPACONSENFLG,
                                    ELECTRONICADDRESSSMSCONSENFLAG,
                                    ELECTRONICADDRESSCONSENTCHANEL,
                                    ELECTRONICADDRESSCONSENTEFFDT,
                                    ELECTRONICADDRESSCONSENTSCTID,
                                    ELECTRONICADDRESSTCPABANKENID,
                                    MSG_STAT_CD,
                                    INSERT_DTTM,
                                    CREATED_BY)
                            VALUES (SP.ACCTID,
                                    SP.PHID,
                                    SP.PHSTATUS,
                                    SP.TCFLAG,
                                    SP.SCFLAG,
                                    SP.CCHANNEL,
                                    SP.CEDATE,
                                    SP.CSID,
                                    SP.TBID,
                                    'NEW',
                                    SYSDATE,
                                    SP.UNAME);
                  END LOOP;

                  acct := acct + 1;
               END LOOP;

               j := j + 1;
            END IF;
         END LOOP;

         i := i + 1;
      END IF;

      COMMIT;

      STATUS := 'SUCCESS';
      STATUSMESSAGE := 'PROCEDURE COMPLETED SUCESSFULLY';
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      STATUS := 'FAILURE';
      STATUSMESSAGE := SUBSTR(SQLERRM, INSTR(SQLERRM, ':')+1);
END;


Sample Party XML:

<party>
<id>12345</id>
<electronicAddresses>
<!-- Repeated phoneNumbers>
<phoneNumber>
<id>p123</id>
<phoneStatus>ACTIVE</phoneStatus>
</phoneNumber>
</electronicAddresses>
</party>

Sample Account XML:

<accounts>
<!-- Repeated accounts>
<account>
<id>12345</id>
<ceaseDesistFlag></ceaseDesistFlag>
<ceaseDesistEffDt>2019-03-12</ceaseDesistEffDt>
<ceaseDesistBankerLanId>mannes01</ceaseDesistBankerLanId>

<electronicAddresses>
<!-- Repeated phoneNumbers>
<phoneNumber>
<id>p123</id>
<phoneStatus>ACTIVE</phoneStatus>
<tcpaConsentFlag>1<tcpaConsentFlag>
<smsConsentFlag>0</smsConsentFlag>
<consentChannel>CALL</consentChannel>
<consentEffDt>2019-03-12</consentEffDt>
<consentScriptId>1.0</consentScriptId>
<tcpaBankerLanId>mannes01</tcpaBankerLanId>
</phoneNumber>
</electronicAddresses>

</account>
</accounts>

